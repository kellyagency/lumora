import "./dashboard.css";
import Dashboard from "./Dashboard";
export const metadata = { title: "Lumora Dashboard", robots: { index: false, follow: false } };
export default function Page() { return <Dashboard />; }
